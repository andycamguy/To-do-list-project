# Awesome Inc Web Developer Bootcamp React Template
```
npx create-next-app
```

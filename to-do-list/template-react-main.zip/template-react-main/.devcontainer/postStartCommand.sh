#!/bin/bash
# Update NPM
sudo npm install -g npm
